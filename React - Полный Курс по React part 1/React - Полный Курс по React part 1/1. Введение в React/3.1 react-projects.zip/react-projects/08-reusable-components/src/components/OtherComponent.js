function OtherComponent() {
  return (
    <div>
      <p>Hello from React</p>
    </div>
  )
}

export default OtherComponent

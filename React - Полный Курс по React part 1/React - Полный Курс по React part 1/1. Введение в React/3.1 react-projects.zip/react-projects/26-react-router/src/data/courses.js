const courses = [
  {
    title: 'Complete React Guide',
    slug: 'react',
    id: 257,
  },
  {
    title: 'Complete JavaScript Guide',
    slug: 'javascript',
    id: 573,
  },
  {
    title: 'Complete Python Guide',
    slug: 'python',
    id: 872,
  },
  {
    title: 'Complete Node.js Guide',
    slug: 'node-js',
    id: 361,
  },
]

export default courses

function Counter({ count }) {
  return <h1>Total clicks: {count}</h1>
}

export default Counter

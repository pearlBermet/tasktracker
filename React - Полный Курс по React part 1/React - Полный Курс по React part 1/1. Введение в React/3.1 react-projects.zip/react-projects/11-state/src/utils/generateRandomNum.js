function generateRandomNum(maxNum) {
  return Math.floor(Math.random() * maxNum)
}

export default generateRandomNum
